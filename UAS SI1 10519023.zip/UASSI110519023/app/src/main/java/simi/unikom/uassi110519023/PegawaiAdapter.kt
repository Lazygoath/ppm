package simi.unikom.uassi110519023

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class PegawaiAdapter(private val pegawaiList: List<Pegawai>) : RecyclerView.Adapter<PegawaiAdapter.PegawaiViewHolder>() {
    class PegawaiViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val namaLengkap: TextView = view.findViewById(R.id.namaLengkap)
        val usia: TextView = view.findViewById(R.id.usia)
        val jabatan: TextView = view.findViewById(R.id.jabatan)
        val keahlian: TextView = view.findViewById(R.id.keahlian)
        val gaji: TextView = view.findViewById(R.id.gaji)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PegawaiViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_pegawai, parent, false)
        return PegawaiViewHolder(view)
    }

    override fun onBindViewHolder(holder: PegawaiViewHolder, position: Int) {
        val pegawai = pegawaiList[position]
        holder.namaLengkap.text = pegawai.nama_lengkap
        holder.usia.text = pegawai.usia.toString()
        holder.jabatan.text = pegawai.jabatan
        holder.keahlian.text = pegawai.keahlian
        holder.gaji.text = pegawai.gaji.toString()
    }

    override fun getItemCount(): Int {
        return pegawaiList.size
    }
}
