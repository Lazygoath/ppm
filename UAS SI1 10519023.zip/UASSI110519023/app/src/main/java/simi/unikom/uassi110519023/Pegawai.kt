package simi.unikom.uassi110519023

data class Pegawai(
    val id_pegawai: Int,
    val nama_lengkap: String,
    val usia: Int,
    val jabatan: String,
    val keahlian: String,
    val gaji: Int
)
