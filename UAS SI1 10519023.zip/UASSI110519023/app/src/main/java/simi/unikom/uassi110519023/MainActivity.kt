package simi.unikom.uassi110519023

import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
class MainActivity : AppCompatActivity() {

    private lateinit var apiService: ApiService
    private lateinit var recyclerView: RecyclerView
    private lateinit var pegawaiAdapter: PegawaiAdapter
    private var pegawaiList: MutableList<Pegawai> = mutableListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        // Setup Window Insets
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
// Inisialisasi ApiService
        apiService = ApiClient.apiService

        // Setup RecyclerView
        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        pegawaiAdapter = PegawaiAdapter(pegawaiList)
        recyclerView.adapter = pegawaiAdapter

        // Fetch data pegawai
        fetchPegawai()
    }
    private fun fetchPegawai() {
        apiService.getPegawai().enqueue(object : Callback<List<Pegawai>> {
            override fun onResponse(call: Call<List<Pegawai>>, response: Response<List<Pegawai>>) {
                if (response.isSuccessful) {
                    pegawaiList.clear()
                    response.body()?.let { pegawaiList.addAll(it) }
                    pegawaiAdapter.notifyDataSetChanged()
                }
            }

            override fun onFailure(call: Call<List<Pegawai>>, t: Throwable) {
                Toast.makeText(this@MainActivity, "Failed to fetch data", Toast.LENGTH_SHORT).show()
            }
        })
    }
}