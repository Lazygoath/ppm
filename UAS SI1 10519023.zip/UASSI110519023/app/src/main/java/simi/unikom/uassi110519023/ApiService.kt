package simi.unikom.uassi110519023

import retrofit2.Call
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.GET
import retrofit2.http.POST

interface ApiService {
    @GET("get_pegawai.php")
    fun getPegawai(): Call<List<Pegawai>>

    @FormUrlEncoded
    @POST("add_pegawai.php")
    fun addPegawai(
        @Field("nama_lengkap") namaLengkap: String,
        @Field("usia") usia: Int,
        @Field("jabatan") jabatan: String,
        @Field("keahlian") keahlian: String,
        @Field("gaji") gaji: Int
    ): Call<Void>

    @FormUrlEncoded
    @POST("update_pegawai.php")
    fun updatePegawai(
        @Field("id_pegawai") idPegawai: Int,
        @Field("nama_lengkap") namaLengkap: String,
        @Field("usia") usia: Int,
        @Field("jabatan") jabatan: String,
        @Field("keahlian") keahlian: String,
        @Field("gaji") gaji: Int
    ): Call<Void>

    @FormUrlEncoded
    @POST("delete_pegawai.php")
    fun deletePegawai(@Field("id_pegawai") idPegawai: Int): Call<Void>
}